#!/bin/bash

cd ../
LROOT=$PWD
vmlinux = $LROOT/linux-5.4

cd $vmlinux
echo "pwd = $vmlinux"
gdb-multiarch --tui $vmlinux