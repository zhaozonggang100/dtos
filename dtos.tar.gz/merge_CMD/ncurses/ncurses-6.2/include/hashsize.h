/*
 * hashsize.h -- hash and token table constants
 */

#define CAPTABSIZE	497
#define HASHTABSIZE	(497 * 2)
