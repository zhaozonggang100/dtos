#ifndef HEADER_OpenBSDProcessField
#define HEADER_OpenBSDProcessField
/*
htop - openbsd/ProcessField.h
(C) 2020 htop dev team
Released under the GNU GPLv2, see the COPYING file
in the source distribution for its full text.
*/


#define PLATFORM_PROCESS_FIELDS  \
   // End of list


#endif /* HEADER_OpenBSDProcessField */
